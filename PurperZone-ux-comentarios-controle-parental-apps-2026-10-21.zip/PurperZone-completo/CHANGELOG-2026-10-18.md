# Alterações desta atualização

- Comparada a estrutura local enviada com a árvore `main` de `GabrielPurper/PurperZone`.
- Preservada a versão local mais completa; a versão do GitHub contém um conjunto menor/mais antigo de arquivos em várias áreas, portanto não foi usada para sobrescrever os arquivos locais mais avançados.
- Adicionado `supabase/performance-indexes.sql`, com os 20 índices de chaves estrangeiras aplicados no Supabase.
- Adicionado `SUPABASE-PERFORMANCE-REPORT.md`, com a verificação (154 FKs analisadas, 0 FKs sem índice), benefícios esperados e pendências de segurança/desempenho.
- Não foram removidos arquivos existentes nem alteradas políticas RLS.
- A conexão OAuth de provedores, autenticação Google/GitHub, pagamentos e fluxos de ponta a ponta continuam dependendo de configuração/testes no painel do Supabase e nos provedores; este pacote não declara esses fluxos como validados.


## 2026-10-21 — Proteção dissuasória de mídia
- Removidas ações simples de download em controles de vídeo dos Reels e clipes gamer.
- Bloqueados menu de contexto e arrastar/soltar diretamente sobre mídia.
- Stories deixam de oferecer link direto para abrir formatos de mídia não suportados.
- Documentadas limitações: isso não impede capturas de tela nem substitui políticas privadas do Supabase Storage.

## 2026-10-21 — Biblioteca unificada em formato de galeria
- A Biblioteca agora apresenta uma grade visual inspirada em galerias sociais, com filtros para Tudo, Social, Fotos, Reels, Código, Projetos e Games.
- A galeria combina posts públicos, anexos ativos de `post_media`, projetos públicos e jogos públicos, ordenados por data.
- Mídias privadas são exibidas por URL assinada temporária quando as políticas do Storage permitem. Isso não impede captura de tela ou cópia por quem consegue visualizar o conteúdo.
- A coleção pessoal baseada em `library_items` foi preservada separadamente em uma seção expansível.
- Para validar a galeria real, confira as políticas RLS de `posts`, `post_media`, `projects`, `games` e o acesso ao bucket `post-media`.
