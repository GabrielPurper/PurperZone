/**
 * GUIA DE MANUTENÇÃO — projects.js
 * Objetivo: Descoberta de projetos e notícias para desenvolvimento.
 * Como modificar: Combina busca pública do GitHub, catálogo npm e conteúdo da comunidade no Supabase. Para incluir outro ecossistema, crie uma função de carregamento, trate erros e renderize cartões usando escapeHtml.
 * Convenções: mantenha funções pequenas, use nomes claros, trate erros de rede e nunca exponha segredos no frontend.
 */

import {supabaseClient} from './supabaseClient.js';
import {escapeHtml} from './app.js';
const list=document.querySelector('#projects-list'),updates=document.querySelector('#dev-updates'),packages=document.querySelector('#package-updates'),codeList=document.querySelector('#code-community'),input=document.querySelector('#dev-search');
const esc=escapeHtml;let timer;
/**
 * Renderiza um cartão reutilizável para uma fonte externa.
 */
function externalCard(tag,title,description,url,meta=''){return `<article class="card dev-update-card"><span class="tag">${esc(tag)}</span><h3>${esc(title)}</h3><p>${esc(description||'')}</p>${meta?`<small class="muted">${esc(meta)}</small>`:''}<a class="btn" href="${url}" target="_blank" rel="noopener noreferrer">Abrir fonte ↗</a></article>`}
/**
 * Busca repositórios públicos recentemente atualizados no GitHub.
 */
async function loadGitHub(q='javascript'){
 try{
  const res=await fetch(`https://api.github.com/search/repositories?q=${encodeURIComponent(q)}&sort=updated&order=desc&per_page=8`,{headers:{Accept:'application/vnd.github+json'}});
  if(!res.ok)throw new Error('GitHub API indisponível');const data=await res.json();
  updates.innerHTML=(data.items||[]).length?data.items.map(x=>externalCard('GitHub',x.full_name,x.description,x.html_url,`★ ${x.stargazers_count} · Atualizado ${new Date(x.updated_at).toLocaleDateString('pt-BR')}`)).join(''):'<div class="empty">Nenhum repositório encontrado.</div>';
 }catch{updates.innerHTML='<div class="empty">Não foi possível carregar as novidades do GitHub agora. <a href="https://github.com/explore" target="_blank" rel="noopener noreferrer">Explorar GitHub ↗</a></div>'}
}
/**
 * Busca pacotes públicos no registro npm.
 */
async function loadNpm(q='react'){
 try{
  const res=await fetch(`https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(q)}&size=6`,{headers:{Accept:'application/json'}});
  if(!res.ok)throw new Error('npm indisponível');const data=await res.json();
  packages.innerHTML=(data.objects||[]).length?data.objects.map(o=>{const x=o.package;return externalCard('npm',x.name,x.description,`https://www.npmjs.com/package/${encodeURIComponent(x.name)}`,`Versão ${x.version||'não informada'}${x.date?' · Publicado '+new Date(x.date).toLocaleDateString('pt-BR'):''}`)}).join(''):'<div class="empty">Nenhum pacote encontrado.</div>';
 }catch{packages.innerHTML='<div class="empty">Não foi possível carregar pacotes agora. <a href="https://www.npmjs.com/" target="_blank" rel="noopener noreferrer">Explorar npm ↗</a></div>'}
}
/**
 * Carrega projetos publicados pela comunidade no Supabase.
 */
async function loadProjects(){
 if(!supabaseClient){list.innerHTML='<div class="empty">Supabase não está disponível.</div>';return}
 const {data,error}=await supabaseClient.from('projects').select('id,name,description,repo_url,status,created_at,is_public').eq('is_public',true).order('created_at',{ascending:false}).limit(20);
 if(error){list.innerHTML=`<div class="empty">Não foi possível carregar projetos da comunidade: ${esc(error.message)}</div>`;return}
 list.innerHTML=(data||[]).length?(data||[]).map(x=>`<article class="card project-card"><span class="tag">${esc(x.status||'Projeto da comunidade')}</span><h3>${esc(x.name||'Projeto')}</h3><p>${esc(x.description||'Sem descrição.')}</p>${x.repo_url?`<a class="btn" href="${esc(x.repo_url)}" target="_blank" rel="noopener noreferrer">Repositório ↗</a>`:''}</article>`).join(''):'<div class="empty">Ainda não há projetos públicos. Compartilhe um projeto pelo Painel Principal.</div>';
}
/**
 * Carrega discussões/publicações relacionadas a programação.
 */
async function loadCode(){
 if(!supabaseClient){codeList.innerHTML='<div class="empty">Supabase não está disponível.</div>';return}
 const {data,error}=await supabaseClient.from('posts').select('id,content,created_at,metadata').in('status',['published','unlisted']).is('deleted_at',null).order('created_at',{ascending:false}).limit(50);
 if(error){codeList.innerHTML='<div class="empty">Não foi possível carregar discussões.</div>';return}
 const items=(data||[]).filter(x=>x.metadata?.content_type==='code'||/```|erro:|exception|bug|como (faço|resolver)|stack ?overflow|código/i.test(x.content||''));
 codeList.innerHTML=items.length?items.slice(0,8).map(x=>`<article class="card"><span class="tag">Pergunta / solução</span><p>${esc((x.content||'').slice(0,700))}</p><a class="btn" href="post.html?id=${encodeURIComponent(x.id)}">Ver discussão ↗</a></article>`).join(''):'<div class="empty">Ainda não há perguntas de código identificadas. Use o Painel Principal para compartilhar um problema, trecho de código ou solução.</div>';
}
/**
 * Espera brevemente após a digitação para evitar excesso de chamadas às APIs externas.
 */
function searchExternal(){const q=input.value.trim();clearTimeout(timer);timer=setTimeout(()=>{loadGitHub(q||'javascript');loadNpm(q||'react')},350)}
input?.addEventListener('input',searchExternal);
loadGitHub();loadNpm();loadProjects();loadCode();

// Formulários de publicação: projetos são registros próprios; snippets são posts do tipo code.
const repositoryForm=document.querySelector('#repository-form');
const codeForm=document.querySelector('#code-publish-form');
const repositoryFeedback=document.querySelector('#repository-feedback');
const codeFeedback=document.querySelector('#code-feedback');
function setFeedback(target,message,isError=false){if(target){target.textContent=message;target.classList.toggle('error-text',isError)}}
function setProjectTab(tab){if(repositoryForm)repositoryForm.hidden=tab!=='repository';if(codeForm)codeForm.hidden=tab!=='code';document.querySelectorAll('[data-project-tab]').forEach(b=>{const active=b.dataset.projectTab===tab;b.classList.toggle('btn--primary',active);b.setAttribute('aria-pressed',String(active))})}
document.querySelectorAll('[data-project-tab]').forEach(b=>b.addEventListener('click',()=>setProjectTab(b.dataset.projectTab)));
document.querySelectorAll('[data-copy-prompt]').forEach(b=>b.addEventListener('click',async()=>{const value=b.dataset.copyPrompt||'';try{await navigator.clipboard.writeText(value);b.textContent='Copiado ✓';setTimeout(()=>b.textContent='Copiar prompt',1600)}catch{const area=document.createElement('textarea');area.value=value;document.body.append(area);area.select();const ok=document.execCommand('copy');area.remove();b.textContent=ok?'Copiado ✓':'Selecione e copie o texto';setTimeout(()=>b.textContent='Copiar prompt',1800)}}));
repositoryForm?.addEventListener('submit',async event=>{event.preventDefault();setFeedback(repositoryFeedback,'Salvando projeto…');if(!supabaseClient){setFeedback(repositoryFeedback,'Supabase não está configurado nesta instalação.',true);return}const {data:{user}}=await supabaseClient.auth.getUser();if(!user){setFeedback(repositoryFeedback,'Entre na sua conta antes de publicar.',true);return}const fd=new FormData(repositoryForm);const name=String(fd.get('name')||'').trim(),description=String(fd.get('description')||'').trim(),repoUrl=String(fd.get('repo_url')||'').trim();if(repoUrl&&!/^https:\/\/(github\.com|gitlab\.com|bitbucket\.org)\//i.test(repoUrl)){setFeedback(repositoryFeedback,'Use um link HTTPS de GitHub, GitLab ou Bitbucket.',true);return}const row={owner_id:user.id,name,description,repo_url:repoUrl||null,status:'published',is_public:fd.has('is_public'),tech_stack:String(fd.get('tech_stack')||'').split(',').map(x=>x.trim()).filter(Boolean)};const {error}=await supabaseClient.from('projects').insert(row);if(error){setFeedback(repositoryFeedback,`Não foi possível criar o projeto: ${error.message}. Confira as colunas e as políticas RLS da tabela projects.`,true);return}repositoryForm.reset();setFeedback(repositoryFeedback,'Projeto criado! Ele aparecerá na listagem após atualizar.');await loadProjects()});
codeForm?.addEventListener('submit',async event=>{event.preventDefault();setFeedback(codeFeedback,'Publicando código…');if(!supabaseClient){setFeedback(codeFeedback,'Supabase não está configurado nesta instalação.',true);return}const {data:{user}}=await supabaseClient.auth.getUser();if(!user){setFeedback(codeFeedback,'Entre na sua conta antes de publicar.',true);return}const fd=new FormData(codeForm);const title=String(fd.get('title')||'').trim(),language=String(fd.get('language')||'Outra'),description=String(fd.get('description')||'').trim(),code=String(fd.get('code')||'').trim();if(!title||!code){setFeedback(codeFeedback,'Preencha o título e o código.',true);return}const content=`${title}${description?'\n\n'+description:''}\n\n\`\`\`${language.toLowerCase()}\n${code}\n\`\`\``;const {error}=await supabaseClient.from('posts').insert({content,author_id:user.id,status:'published',visibility:fd.has('is_public')?'public':'private',metadata:{content_type:'code',title,language,description}});if(error){setFeedback(codeFeedback,`Não foi possível publicar o código: ${error.message}. Confira a política RLS da tabela posts.`,true);return}codeForm.reset();setFeedback(codeFeedback,'Código publicado no feed da comunidade.');await loadCode()});
